import { StatusBar, View, Text } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import { GluestackUIProvider } from '@/components/ui/gluestack-ui-provider';

import MainTabs from './navigation/MainTabs';
import ProductDetailsScreen from './screens/ProductDetailsScreen';

import ProductCreateScreen from './screens/ProductCreateScreen';

import RegisterScreen from './screens/RegisterScreen';

import LoginScreen from './screens/LoginScreen';

import ProfileScreen from './screens/ProfileScreen';

import { AuthProvider } from './context/AuthContext';

import ProductEditScreen from './screens/ProductEditScreen';

import '@/global.css';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <GluestackUIProvider mode="light">
      <SafeAreaProvider>
        <AuthProvider>
          <NavigationContainer>
            <StatusBar barStyle="dark-content" />

            <Stack.Navigator
              screenOptions={{
                headerTitle: () => (
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'baseline',
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 34,
                        fontWeight: '800',
                        letterSpacing: -1.8,
                        color: '#171717',
                      }}
                    >
                      moody
                    </Text>
                    <View
                      style={{
                        width: 8,
                        height: 8,
                        borderRadius: 4,
                        backgroundColor: '#92600C',
                        marginLeft: 2,
                        marginBottom: 3,
                      }}
                    />
                  </View>
                ),
                headerTitleAlign: 'left',
                headerStyle: {
                  backgroundColor: '#FFFFFF',
                },
                headerTintColor: '#171717',
                headerShadowVisible: false,
              }}
            >
              <Stack.Screen
                name="MainTabs"
                component={MainTabs}
                options={{ headerShown: false }}
              />

              <Stack.Screen
                name="ProductDetails"
                component={ProductDetailsScreen}
                options={{ title: 'Product Details' }}
              />

              <Stack.Screen
                name="ProductCreate"
                component={ProductCreateScreen}
                options={{ title: 'Create Product' }}
              />

              <Stack.Screen
                name="Register"
                component={RegisterScreen}
                options={{ title: 'Register' }}
              />

              <Stack.Screen
                name="Login"
                component={LoginScreen}
                options={{ title: 'Login' }}
              />

              <Stack.Screen
                name="Profile"
                component={ProfileScreen}
                options={{ title: 'My Profile' }}
              />

              <Stack.Screen
                name="ProductEdit"
                component={ProductEditScreen}
                options={{ title: 'Edit Product' }}
              />

            </Stack.Navigator>
          </NavigationContainer>
        </AuthProvider>
      </SafeAreaProvider>
    </GluestackUIProvider>
  );
}