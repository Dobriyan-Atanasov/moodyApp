import { File } from 'expo-file-system';
import { fetch as expoFetch } from 'expo/fetch';
import { getAccessToken } from './authService';

const SUPABASE_URL = process.env.EXPO_PUBLIC_SUPABASE_URL;
const SUPABASE_KEY = process.env.EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY;

export async function uploadProductPhoto(photo, productId, userId, index) {
    const token = await getAccessToken();

    if (!token) {
        throw new Error('You must be logged in to upload photos.');
    }

    const file = new File(photo.uri);
    const mimeType = photo.mimeType || file.type || 'image/jpeg';

    const extension = mimeType === 'image/png'
        ? 'png'
        : mimeType === 'image/webp'
            ? 'webp'
            : 'jpg';

    const storagePath =
        `${userId}/${productId}/${Date.now()}-${index}.${extension}`;

    const response = await expoFetch(
        `${SUPABASE_URL}/storage/v1/object/product-images/${storagePath}`,
        {
            method: 'POST',
            headers: {
                apikey: SUPABASE_KEY,
                Authorization: `Bearer ${token}`,
                'Content-Type': mimeType,
            },
            body: file,
        }
    );

    if (!response.ok) {
        const data = await response.json();
        throw new Error(data.message || data.error || 'Photo upload failed.');
    }

    return storagePath;
}


export async function saveProductPhoto(productId, storagePath, displayOrder) {
    const token = await getAccessToken();

    if (!token) {
        throw new Error('You must be logged in to save photos.');
    }

    const response = await fetch(`${SUPABASE_URL}/rest/v1/product_images`, {
        method: 'POST',
        headers: {
            apikey: SUPABASE_KEY,
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            product_id: productId,
            storage_path: storagePath,
            display_order: displayOrder,
        }),
    });

    if (!response.ok) {
        const data = await response.json();
        throw new Error(data.message || 'Failed to save product photo.');
    }
}


export async function deleteProductPhoto(photoId) {
    const token = await getAccessToken();

    if (!token) {
        throw new Error('You must be logged in to delete photos.');
    }

    const response = await fetch(
        `${SUPABASE_URL}/rest/v1/product_images?id=eq.${encodeURIComponent(photoId)}`,
        {
            method: 'DELETE',
            headers: {
                apikey: SUPABASE_KEY,
                Authorization: `Bearer ${token}`,
                Prefer: 'return=representation',
            },
        }
    );

    const data = await response.json();

    if (!response.ok) {
        throw new Error(data.message || 'Failed to delete photo record.');
    }

    if (data.length === 0) {
        throw new Error('Photo not found or deletion is not permitted.');
    }

    return data[0];
}

export async function deletePhotoFromStorage(storagePath) {
    const token = await getAccessToken();

    if (!token) {
        throw new Error('You must be logged in to delete photos.');
    }

    const response = await fetch(
        `${SUPABASE_URL}/storage/v1/object/product-images/${storagePath
            .split('/')
            .map(encodeURIComponent)
            .join('/')}`,
        {
            method: 'DELETE',
            headers: {
                apikey: SUPABASE_KEY,
                Authorization: `Bearer ${token}`,
            },
        }
    );

    if (!response.ok) {
        const data = await response.json();
        throw new Error(data.message || data.error || 'Failed to delete photo from storage.');
    }
}


export async function updateProductPhotoOrder(photoId, displayOrder) {
    const token = await getAccessToken();

    if (!token) {
        throw new Error('You must be logged in to reorder photos.');
    }

    const response = await fetch(
        `${SUPABASE_URL}/rest/v1/product_images?id=eq.${encodeURIComponent(photoId)}`,
        {
            method: 'PATCH',
            headers: {
                apikey: SUPABASE_KEY,
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json',
                Prefer: 'return=representation',
            },
            body: JSON.stringify({ display_order: displayOrder }),
        }
    );

    const data = await response.json();

    if (!response.ok) {
        throw new Error(data.message || 'Failed to reorder photo.');
    }

    if (!data.length) {
        throw new Error('Photo not found or update not permitted.');
    }

    return data[0];
}